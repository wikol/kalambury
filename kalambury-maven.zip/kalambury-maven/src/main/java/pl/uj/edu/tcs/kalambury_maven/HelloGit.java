package pl.uj.edu.tcs.kalambury_maven;

/**
 * Just checking eclipse-github relations
 * @author Wiktor Kuropatwa
 *
 */
public class HelloGit {

}
