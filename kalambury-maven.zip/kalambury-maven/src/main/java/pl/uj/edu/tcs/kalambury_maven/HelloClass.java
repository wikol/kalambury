package pl.uj.edu.tcs.kalambury_maven;

/**
 * 
 * @author Michał Piekarz
 *
 */
public class HelloClass {

}
