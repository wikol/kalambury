package pl.uj.edu.tcs.kalambury_maven.event;

public class DisplayLoginEvent implements Event {

	private static final long serialVersionUID = 7596437713260297645L;

}
