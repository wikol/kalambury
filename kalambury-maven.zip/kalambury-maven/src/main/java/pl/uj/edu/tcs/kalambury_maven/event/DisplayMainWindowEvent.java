package pl.uj.edu.tcs.kalambury_maven.event;

public class DisplayMainWindowEvent implements Event {

	private static final long serialVersionUID = -7464237507158904715L;

}
